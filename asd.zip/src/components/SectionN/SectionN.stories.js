import { SectionN } from ".";

export default {
  title: "Components/SectionN",
  component: SectionN,
};

export const Default = {
  args: {
    btnName: "section 1",
    className: {},
    divClassName: {},
  },
};
